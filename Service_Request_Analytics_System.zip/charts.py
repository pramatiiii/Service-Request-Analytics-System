"""
reports/charts.py
==================
Generates all three charts and saves them as PNG files in the output folder.

Library used: matplotlib
-------------------------
matplotlib is Python's standard data visualisation library.
pyplot (plt) provides a simple interface for creating figures.

Key concepts:
    fig  = the entire figure (like a picture frame)
    ax   = the axes / drawing surface inside the figure (like the painting)
    plt.subplots() creates both at once

Install: pip install matplotlib
"""

import os
import matplotlib.pyplot as plt
from analytics.stats import (
    priority_breakdown,
    status_breakdown,
    top_failure_categories,
)

# ── Colour palette ─────────────────────────────────────────────────────────────
# A consistent dark-themed colour scheme used across all charts.
# These hex codes represent specific colours:
#   #A31D1D = deep red      (High priority)
#   #754E1A = earthy brown  (Medium priority)
#   #254F22 = dark green    (Low priority)
PRIORITY_COLORS = {
    "High":   "#A31D1D",
    "Medium": "#754E1A",
    "Low":    "#254F22",
}

STATUS_COLORS = {
    "Open":        "#810B38",
    "In Progress": "#543A14",
    "Completed":   "#313E17",
}

# Gradient colours for the failure category bar chart (ranked 1st to 5th)
FAILURE_COLORS = ["#A31D1D", "#810B38", "#543A14", "#754E1A", "#254F22"]


def _apply_dark_theme(fig, ax):
    """
    Apply a consistent dark background theme to any chart.

    Parameters
    ----------
    fig : matplotlib Figure object
    ax  : matplotlib Axes object

    Why a helper function?
    ----------------------
    All three charts need the same dark styling.
    Instead of repeating 8 lines of code in each chart function,
    we define it once here and call it from each chart.
    This follows the DRY principle — Don't Repeat Yourself.

    fig.patch vs ax.set_facecolor:
        ax.set_facecolor  → sets the colour of the PLOT AREA (inside the axes)
        fig.patch         → sets the colour of the WHOLE FIGURE (including margins)
        They are separate surfaces — you need to set both for a full dark theme.
    """
    ax.set_facecolor("#1a1a1a")                 # Dark plot area
    fig.patch.set_facecolor("#111111")          # Even darker outer frame
    ax.tick_params(colors="white")              # White axis tick labels
    ax.xaxis.label.set_color("white")           # White x-axis label
    ax.yaxis.label.set_color("white")           # White y-axis label
    ax.title.set_color("white")                 # White chart title
    ax.spines["top"].set_visible(False)         # Remove top border line
    ax.spines["right"].set_visible(False)       # Remove right border line
    ax.spines["left"].set_color("#555555")      # Subtle grey left border
    ax.spines["bottom"].set_color("#555555")    # Subtle grey bottom border


def generate_priority_chart(requests, output_dir="output"):
    """
    Chart 1: Priority Distribution — vertical bar chart.

    Parameters
    ----------
    requests   : list of ServiceRequest objects
    output_dir : folder to save the chart PNG

    Returns
    -------
    str — file path of the saved chart

    What this chart shows:
    How many tickets are High vs Medium vs Low priority.
    A bar chart is best here because we are comparing discrete categories.

    Key matplotlib calls:
        ax.bar()   → draws the bars
        ax.text()  → adds a number label above each bar
        plt.tight_layout() → adjusts spacing so nothing gets cut off
        plt.savefig()      → saves as PNG
        plt.close()        → frees memory (important in loops or long scripts)
    """
    os.makedirs(output_dir, exist_ok=True)

    # Get the count per priority level
    pb         = priority_breakdown(requests)
    priorities = list(pb.keys())
    counts     = list(pb.values())

    # Map each priority label to its colour
    bar_colors = [PRIORITY_COLORS.get(p, "#888888") for p in priorities]

    # Create the figure and axes
    # figsize=(8, 5) sets width=8 inches, height=5 inches
    fig, ax = plt.subplots(figsize=(8, 5))

    # Draw the bars
    # edgecolor="white" draws a thin white border around each bar
    bars = ax.bar(priorities, counts, color=bar_colors, edgecolor="white", linewidth=1.2)

    # Chart labels and title
    ax.set_title("Priority Distribution", fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel("Priority Level", fontsize=11)
    ax.set_ylabel("Number of Requests", fontsize=11)

    # Apply dark theme
    _apply_dark_theme(fig, ax)

    # Add a number label above each bar
    # bar.get_x() + bar.get_width()/2  → horizontal centre of the bar
    # bar.get_height() + 3             → just above the top of the bar
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_x() + bar.get_width() / 2,   # x position: centre of bar
            bar.get_height() + 3,                 # y position: just above bar
            str(count),                           # text to display
            ha="center", va="bottom",             # alignment
            color="white", fontsize=11,
        )

    plt.tight_layout()  # Auto-adjust layout so labels aren't cut off

    filepath = os.path.join(output_dir, "priority_chart.png")
    plt.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close()  # Free memory — always close after saving

    print(f"[✓] Priority chart saved → {filepath}")
    return filepath


def generate_status_chart(requests, output_dir="output"):
    """
    Chart 2: Status Distribution — pie chart.

    Parameters
    ----------
    requests   : list of ServiceRequest objects
    output_dir : folder to save the chart PNG

    Returns
    -------
    str — file path of the saved chart

    What this chart shows:
    The proportion of tickets in each status as a percentage of the whole.
    A pie chart is appropriate here because the three values always add up to 100%.

    Key matplotlib calls:
        ax.pie()    → draws the pie chart
        autopct     → format string for the percentage labels on each slice
                      "%1.1f%%" means: float with 1 decimal place, then a % sign
                      The double %% escapes to a literal % character
        explode     → list of offsets — small positive value slightly separates
                      each slice from the centre, making them easier to read
        startangle  → rotates the starting angle of the first slice
    """
    os.makedirs(output_dir, exist_ok=True)

    sb          = status_breakdown(requests)
    statuses    = list(sb.keys())
    status_vals = list(sb.values())
    pie_colors  = [STATUS_COLORS.get(s, "#888888") for s in statuses]

    # Slight separation for each slice (same small value for all slices)
    explode = [0.03] * len(statuses)

    fig, ax = plt.subplots(figsize=(7, 7))

    # Draw the pie chart
    # wedges, texts, autotexts are the three groups of elements matplotlib returns
    wedges, texts, autotexts = ax.pie(
        status_vals,
        labels      = statuses,
        colors      = pie_colors,
        autopct     = "%1.1f%%",        # Show percentage on each slice
        explode     = explode,          # Slight gap between slices
        startangle  = 140,             # Rotate starting position
        textprops   = {"color": "white", "fontsize": 11},
        wedgeprops  = {"edgecolor": "#111111", "linewidth": 1.5},
    )

    # Make the percentage labels white and slightly smaller
    for autotext in autotexts:
        autotext.set_color("white")
        autotext.set_fontsize(10)

    ax.set_title("Status Distribution", fontsize=14, fontweight="bold",
                 color="white", pad=15)
    fig.patch.set_facecolor("#111111")

    filepath = os.path.join(output_dir, "status_chart.png")
    plt.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[✓] Status chart saved  → {filepath}")
    return filepath


def generate_failure_chart(requests, output_dir="output"):
    """
    Chart 3: Top Failure Categories — horizontal bar chart.

    Parameters
    ----------
    requests   : list of ServiceRequest objects
    output_dir : folder to save the chart PNG

    Returns
    -------
    str — file path of the saved chart

    What this chart shows:
    The 5 most common reasons machines fail, ranked by frequency.
    A horizontal bar chart is used for ranked categories because:
        - Category labels are long and fit better horizontally
        - The ranking reads naturally top-to-bottom

    Key matplotlib calls:
        ax.barh()        → horizontal bars (h = horizontal)
        ax.invert_yaxis() → puts rank #1 at the TOP
                           (by default matplotlib puts the first item at the bottom)
    """
    os.makedirs(output_dir, exist_ok=True)

    top_failures = top_failure_categories(requests, n=5)
    categories   = [cat for cat, _ in top_failures]    # category names
    counts       = [cnt for _, cnt in top_failures]    # occurrence counts

    fig, ax = plt.subplots(figsize=(9, 5))

    # Draw horizontal bars
    bars = ax.barh(
        categories,
        counts,
        color      = FAILURE_COLORS[:len(categories)],
        edgecolor  = "white",
        linewidth  = 0.8,
        height     = 0.55,   # bar thickness (0 to 1, where 1 = touching bars)
    )

    ax.set_title("Top Failure Categories", fontsize=14, fontweight="bold", pad=15)
    ax.set_xlabel("Number of Occurrences", fontsize=11)
    ax.invert_yaxis()  # Rank #1 at the top

    _apply_dark_theme(fig, ax)

    # Add count labels to the right of each bar
    # bar.get_width()  → the length (value) of the bar
    # bar.get_y() + bar.get_height()/2 → vertical centre of the bar
    for bar, count in zip(bars, counts):
        ax.text(
            bar.get_width() + 1,                        # x: just past end of bar
            bar.get_y() + bar.get_height() / 2,         # y: centre of bar
            str(count),
            va="center", color="white", fontsize=11,
        )

    plt.tight_layout()

    filepath = os.path.join(output_dir, "failure_chart.png")
    plt.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close()

    print(f"[✓] Failure chart saved → {filepath}")
    return filepath


def generate_all_charts(requests, output_dir="output"):
    """
    Convenience function — generates all three charts in one call.

    Parameters
    ----------
    requests   : list of ServiceRequest objects
    output_dir : output folder

    Returns
    -------
    list of file paths for the three saved charts
    """
    paths = [
        generate_priority_chart(requests, output_dir),
        generate_status_chart(requests, output_dir),
        generate_failure_chart(requests, output_dir),
    ]
    return paths
