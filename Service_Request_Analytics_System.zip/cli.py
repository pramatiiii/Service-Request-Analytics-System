"""
cli.py
=======
The interactive Command-Line Interface (CLI) menu for the system.

What is a CLI?
A CLI is a text-based interface where the user types commands instead of
clicking buttons. This is the standard interface for tools that run in
a terminal / command prompt.

Why a separate file?
The menu logic (what to show, what to do when the user picks an option)
is separate from both the analytics and the report generation.
If you ever want to add a web interface or a GUI later, you can do so
without touching any of the analytics or report files.
"""

from reports.display      import (
    show_summary,
    show_open_requests,
    show_high_priority_requests,
    show_completed_requests,
    show_technician_performance,
)
from reports.charts       import generate_all_charts
from reports.text_report  import generate_text_report
from reports.excel_report import generate_excel_report


def print_banner():
    """Print the application title banner."""
    print("\n" + "=" * 40)
    print("  Service Request Analytics System")
    print("=" * 40)


def print_menu():
    """Print the numbered menu options."""
    print("  1. View Summary")
    print("  2. View Open Requests")
    print("  3. View High Priority Requests")
    print("  4. View Completed Requests")
    print("  5. View Technician Performance")
    print("  6. Generate Charts")
    print("  7. Export to Excel")
    print("  8. Generate Full Report (all outputs)")
    print("  9. Exit")
    print("=" * 40)


def run_cli(requests, df, output_dir="output"):
    """
    Run the interactive CLI menu loop.

    Parameters
    ----------
    requests   : list of ServiceRequest objects (pre-loaded)
    df         : pandas DataFrame (pre-loaded)
    output_dir : where output files will be saved

    How the event loop works:
    -------------------------
    'while True' creates an infinite loop — it runs forever until something
    explicitly stops it. The 'break' statement inside option 9 is what stops it.

    This pattern (loop → wait for input → act → loop again) is called an
    EVENT LOOP — the same fundamental pattern used in web servers, games,
    and GUI applications.

    input() pauses the entire program and waits for the user to type
    something and press Enter. It ALWAYS returns a string.

    .strip() removes any accidental leading/trailing whitespace.
    Without it, typing " 1" (space then 1) would not match "1" and
    the menu would show "Invalid choice" — a common beginner bug.
    """

    while True:
        print_banner()
        print_menu()

        # Wait for user input — the program pauses here until Enter is pressed
        choice = input("  Enter your choice: ").strip()

        if choice == "1":
            show_summary(requests, df)

        elif choice == "2":
            show_open_requests(requests)

        elif choice == "3":
            show_high_priority_requests(requests)

        elif choice == "4":
            show_completed_requests(requests)

        elif choice == "5":
            show_technician_performance(df)

        elif choice == "6":
            print("\n  Generating charts...")
            generate_all_charts(requests, output_dir)
            print("  Saved to output/ folder.\n")

        elif choice == "7":
            generate_excel_report(requests, df, output_dir)

        elif choice == "8":
            # Generate every output in one go
            print("\n  Generating full report...")
            generate_text_report(requests, df, output_dir)
            generate_all_charts(requests, output_dir)
            generate_excel_report(requests, df, output_dir)
            print("  All outputs saved to output/ folder.\n")

        elif choice == "9":
            # 'break' exits the while True loop — the only way out
            print("\n  Goodbye!\n")
            break

        else:
            # Catch any input that isn't 1–9
            print("\n  [!] Invalid choice. Please enter a number from 1 to 9.\n")
